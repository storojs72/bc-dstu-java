package org.bouncycastle.crypto;

public class OutputLengthException
    extends DataLengthException
{
    public OutputLengthException(String msg)
    {
        super(msg);
    }
}
