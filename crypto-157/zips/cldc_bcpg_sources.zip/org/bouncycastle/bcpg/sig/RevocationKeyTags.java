package org.bouncycastle.bcpg.sig;

public interface RevocationKeyTags
{
    public static final byte CLASS_DEFAULT = (byte)0x80;
    public static final byte CLASS_SENSITIVE = (byte)0x40;

}
